package com.btec.fpt.campus_expense_manager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.btec.fpt.campus_expense_manager.entities.Category;
import com.btec.fpt.campus_expense_manager.entities.Transaction;
import com.btec.fpt.campus_expense_manager.models.Item;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    private Context context;
    private List<Transaction> itemList;

    // Constructor
    public ItemAdapter(Context context, List<Transaction> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the custom layout for each item
        View view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        // Get the current item
        Transaction item = itemList.get(position);

        // Bind data to the views
        holder.imageView.setImageResource(R.drawable.item1);
        holder.textView.setText(item.getCategory());
        holder.textViewTime.setText(item.getDate());
        holder.textViewAmount.setText(String.valueOf(item.getAmount()));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // ViewHolder class to represent each item
    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView textView;
        TextView textViewTime;
        TextView textViewAmount     ;


        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.item_image);
            textView = itemView.findViewById(R.id.item_text);
            textViewTime = itemView.findViewById(R.id.item_time);
            textViewAmount = itemView.findViewById(R.id.item_amount);
        }
    }
}

