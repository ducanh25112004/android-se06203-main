package com.btec.fpt.campus_expense_manager.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.btec.fpt.campus_expense_manager.HomeActivity;
import com.btec.fpt.campus_expense_manager.R;
import com.btec.fpt.campus_expense_manager.database.DatabaseHelper;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginFragment extends Fragment {

    private EditText edtEmail;
    private EditText edtPassword;
    private CheckBox rememberMeCheckBox;
    private DatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;
    private View view;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_login, container, false);
        sharedPreferences = getActivity().getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        databaseHelper = new DatabaseHelper(getContext());

        // Find views
        edtEmail = view.findViewById(R.id.email);
        edtPassword = view.findViewById(R.id.password);
        rememberMeCheckBox = view.findViewById(R.id.remember_me);
        Button loginButton = view.findViewById(R.id.login_button);
        Button registerButton = view.findViewById(R.id.goto_register_button);
        Button forgotPasswordButton = view.findViewById(R.id.goto_forgot_password_button);

        // Set up button click listeners
        loginButton.setOnClickListener(v -> loginUser(editor));
        registerButton.setOnClickListener(v -> loadFragment(new RegisterFragment()));
        forgotPasswordButton.setOnClickListener(v -> showCustomAlertDialog());

        // Check if user is already logged in
        if (sharedPreferences.getBoolean("isLoggedIn", false)) {
            edtEmail.setText(sharedPreferences.getString("email", ""));
            edtPassword.setText(sharedPreferences.getString("password", ""));
            rememberMeCheckBox.setChecked(true);
        }

        return view;
    }

    private void loginUser(SharedPreferences.Editor editor) {
        String email = edtEmail.getText().toString();
        String pwd = edtPassword.getText().toString();

        if (!email.isEmpty() && !pwd.isEmpty()) {
            boolean check = databaseHelper.signIn(email, pwd);

            if (check) {
                if (rememberMeCheckBox.isChecked()) {
                    editor.putString("email", email);
                    editor.putString("password", pwd);
                    editor.putBoolean("isLoggedIn", true);
                } else {
                    editor.clear();
                }
                editor.apply();

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                startActivity(intent);
            } else {
                showToastCustom("Email or password incorrect!");
            }
        } else {
            showToastCustom("Email or password is invalid !!!");
        }
    }

    private void showToastCustom(String message) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, view.findViewById(R.id.custom_toast_layout));
        ImageView icon = layout.findViewById(R.id.toast_icon);
        icon.setImageResource(R.drawable.icon_x);
        TextView text = layout.findViewById(R.id.toast_message);
        text.setText(message);
        Toast toast = new Toast(getContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }

    private void showCustomAlertDialog() {
        LayoutInflater inflater = getLayoutInflater();
        View customView = inflater.inflate(R.layout.dialog_custom, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setView(customView);
        final EditText input = customView.findViewById(R.id.dialog_input);
        TextView title = customView.findViewById(R.id.dialog_title);
        Button okButton = customView.findViewById(R.id.dialog_button_ok);
        title.setText("Forgot password!");
        AlertDialog dialog = builder.create();
        okButton.setOnClickListener(v -> {
            String userInput = input.getText().toString();
            if (isValidEmail(userInput)) {
                loadFragment(new ForgotPasswordFragment());
            } else {
                showToastCustom("Email is invalid !");
            }
            dialog.dismiss();
        });
        dialog.show();
    }

    private boolean isValidEmail(String email) {
        return !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}