package com.btec.fpt.campus_expense_manager.fragments;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.btec.fpt.campus_expense_manager.DataUtils;
import com.btec.fpt.campus_expense_manager.HomeActivity;
import com.btec.fpt.campus_expense_manager.ItemAdapter;
import com.btec.fpt.campus_expense_manager.R;
import com.btec.fpt.campus_expense_manager.database.DatabaseHelper;
import com.btec.fpt.campus_expense_manager.entities.Category;
import com.btec.fpt.campus_expense_manager.entities.Transaction;
import com.btec.fpt.campus_expense_manager.models.BalanceInfor;
import com.btec.fpt.campus_expense_manager.models.Item;

import java.util.List;

public class HomeFragment extends Fragment {
    private DatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;
    private ImageView iconX;

    public HomeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize components
        databaseHelper = new DatabaseHelper(getContext());
        sharedPreferences = getActivity().getSharedPreferences("UserPrefs", MODE_PRIVATE);

        // Map views
        TextView tvFullName = view.findViewById(R.id.tvFullname);
        TextView tvBalance = view.findViewById(R.id.tvBalance);
        TextView tvHello = view.findViewById(R.id.tv_name);
        iconX = view.findViewById(R.id.iconX);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        Button btnAddExpense = view.findViewById(R.id.btnAddExpense);
        Button btnAddBudget = view.findViewById(R.id.btnAddBudget);
        Button btnAddIncome = view.findViewById(R.id.btnAddIncome);
        Spinner spinnerFilter = view.findViewById(R.id.spinnerFilter);
        Button btnSearch = view.findViewById(R.id.btnSearch);

        // Handle user information
        String email = sharedPreferences.getString("email", null);
        String password = sharedPreferences.getString("password", null);

        DataUtils.email = email;
        DataUtils.password = password;

        BalanceInfor balanceInfor = databaseHelper.getBalanceFromEmail(email);

        // Update user information
        tvFullName.setText(balanceInfor.getFirstName() + " " + balanceInfor.getLastName());
        tvBalance.setText(String.format("%,.0f VND", balanceInfor.getBalance()));
        tvHello.setText("Hello " + balanceInfor.getFirstName());

        // Handle RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        List<Transaction> transactionList = databaseHelper.getAllTransactionsByEmail(DataUtils.email);
        ItemAdapter itemAdapter = new ItemAdapter(getContext(), transactionList);
        recyclerView.setAdapter(itemAdapter);

        // Set up Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.filter_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(adapter);

        // Handle button clicks
        btnAddExpense.setOnClickListener(v -> loadFragment(new AddExpenseFragment()));
        btnAddBudget.setOnClickListener(v -> loadFragment(new AddBudgetFragment()));
        btnAddIncome.setOnClickListener(v -> loadFragment(new AddIncomeFragment()));
        btnSearch.setOnClickListener(v -> searchTransactions(spinnerFilter.getSelectedItemPosition()));

        // Handle iconX click
        iconX.setOnClickListener(this::showUserOptionsMenu);

        return view;
    }

    private void searchTransactions(int filterType) {
        List<Transaction> filteredList;
        if (filterType == 0) {
            filteredList = databaseHelper.getAllTransactionsByEmail(DataUtils.email); // Show All
        } else if (filterType == 1) {
            filteredList = databaseHelper.getTransactionsByType(DataUtils.email, 0); // Expenses
        } else {
            filteredList = databaseHelper.getTransactionsByType(DataUtils.email, 1); // Income
        }
        ItemAdapter itemAdapter = new ItemAdapter(getContext(), filteredList);
        RecyclerView recyclerView = getView().findViewById(R.id.recyclerView);
        recyclerView.setAdapter(itemAdapter);
    }

    // Show user options menu when clicking on iconX
    private void showUserOptionsMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(getContext(), view);
        popupMenu.getMenuInflater().inflate(R.menu.home_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.menu_change_password) {
                // Navigate to change password fragment
                loadFragment(new ChangePasswordFragment());
                return true;
            } else if (itemId == R.id.menu_logout) {
                // Handle logout
                logoutUser();
                return true;
            }

            return false;
        });

        popupMenu.show();
    }

    // Handle user logout
    private void logoutUser() {
        // Clear login information in SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // Navigate to login fragment
        if (getActivity() != null) {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new LoginFragment())
                    .commit();
        }
    }

    // Check if budget is exceeded
    private boolean isBudgetExceeded() {
        SharedPreferences budgetPrefs = getActivity().getSharedPreferences("BudgetPrefs", MODE_PRIVATE);
        float budget = budgetPrefs.getFloat("budget", 0);
        double totalExpense = databaseHelper.getTotalExpenseByEmail(DataUtils.email);
        return totalExpense > budget;
    }

    // Load fragment method
    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    public class HomeActivity extends AppCompatActivity {
        private SharedPreferences sharedPreferences;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home);

            sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

            if (sharedPreferences.getBoolean("isLoggedIn", false)) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new HomeFragment())
                        .commit();
            } else {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new LoginFragment())
                        .commit();
            }
        }
    }
}