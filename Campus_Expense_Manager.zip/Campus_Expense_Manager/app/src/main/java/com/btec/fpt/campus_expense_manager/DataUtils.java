package com.btec.fpt.campus_expense_manager;

public class DataUtils {


    public static String email ;
    public  static String password;
}
